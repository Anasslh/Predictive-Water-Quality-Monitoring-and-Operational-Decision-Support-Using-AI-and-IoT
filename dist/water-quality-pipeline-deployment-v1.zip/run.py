#!/usr/bin/env python3
"""
run.py — Unified CLI entry point for the water-quality monitoring pipeline.

Sub-commands
------------
  onboard   Benchmark RF / XGBoost / SVR for a new sensor parameter,
            then interactively freeze the chosen model.
  monitor   Pass one new measurement through the production model:
            predict, SHAP explanation, anomaly score, rolling JSONL export.
  status    Show current operational state for one or all parameters.
  approve   Review / approve / reject pending model promotion candidates.

Config validation
-----------------
Before any pipeline module is imported, run.py checks that
  • config/system_config.json  exists, is valid JSON, has required fields
  • config/sensors_config.json exists, is valid JSON, has required fields
A clear human-readable error is printed and the process exits if anything
is wrong — no cryptic traceback further down the pipeline.

Default paths follow the standard project layout and can all be overridden
via command-line arguments.

Usage examples
--------------
  python run.py onboard --dataset data/processed/c1_with_wqi.csv \\
                        --parameter Turbidity

  python run.py monitor --parameter EC \\
                        --new-row data/processed/ec_X_test.csv

  python run.py status
  python run.py status --parameter EC

  python run.py approve
  python run.py approve <approval_id>
  python run.py approve --reject-all-stale
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# ── Project root (this file lives at the project root) ────────────────────────
ROOT = Path(__file__).resolve().parent

# Default config paths
_DEFAULT_SYSTEM_CONFIG  = ROOT / "config" / "system_config.json"
_DEFAULT_SENSORS_CONFIG = ROOT / "config" / "sensors_config.json"
_DEFAULT_MODELS_STORE   = ROOT / "models_store"


# ══════════════════════════════════════════════════════════════════════════════
# Config validation — runs BEFORE any src import
# ══════════════════════════════════════════════════════════════════════════════

_SYSTEM_CONFIG_REQUIRED_FIELDS  = ("retraining", "anomaly_detection",
                                    "forecasting", "exports", "logging")
_SENSORS_CONFIG_REQUIRED_FIELDS = ("sensors", "timestamp_column_candidates")


def _validate_configs(
    system_config_path: Path,
    sensors_config_path: Path,
) -> None:
    """
    Validate both config files before any pipeline code runs.

    Checks performed
    ----------------
    1. File exists at the specified path.
    2. File is valid JSON (no parse error).
    3. All required top-level fields are present.

    On any failure: print a clear diagnostic and sys.exit(1).
    """
    errors: list[str] = []

    for path, label, required_fields in (
        (system_config_path,  "system_config.json",  _SYSTEM_CONFIG_REQUIRED_FIELDS),
        (sensors_config_path, "sensors_config.json", _SENSORS_CONFIG_REQUIRED_FIELDS),
    ):
        if not path.exists():
            errors.append(
                f"{label} not found at: {path}\n"
                f"    Expected location: {path}\n"
                f"    Create the file or pass --system-config / --sensors-config "
                f"to point to an alternative location."
            )
            continue   # no point checking fields if file is absent

        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            errors.append(f"{label}: invalid JSON — {exc}")
            continue

        for field in required_fields:
            if field not in raw:
                errors.append(
                    f"{label}: missing required field '{field}'\n"
                    f"    Found fields: {list(raw.keys())}"
                )

        if label == "sensors_config.json":
            sensors = raw.get("sensors", [])
            if not isinstance(sensors, list):
                errors.append("sensors_config.json: field 'sensors' must be a list")
            elif len(sensors) == 0:
                errors.append("sensors_config.json: 'sensors' list is empty — "
                              "add at least one sensor entry")

    if errors:
        print("\n[run.py] Configuration error(s) — cannot proceed:\n")
        for i, err in enumerate(errors, 1):
            for j, line in enumerate(err.splitlines()):
                prefix = f"  {i}. " if j == 0 else "     "
                print(prefix + line)
        print()
        sys.exit(1)


# ══════════════════════════════════════════════════════════════════════════════
# Sub-command implementations
# ══════════════════════════════════════════════════════════════════════════════

def _cmd_onboard(args: argparse.Namespace) -> None:
    """
    onboard: benchmark + interactive freeze for a new sensor parameter.

    Steps
    -----
    1. Load the dataset CSV.
    2. Call onboard_new_parameter() → prints benchmark report(s).
    3. Ask the user to choose a variant (raw / log) and a rank.
    4. Rebuild X_all / y_all for the chosen variant (train + val concatenated).
    5. Call submit_benchmark_choice() to freeze the model.
    """
    import numpy as np
    import pandas as pd
    from src.pipeline.orchestrator import (
        _build_and_split,
        _prepare_data,
        load_sensor_config,
        onboard_new_parameter,
        submit_benchmark_choice,
    )

    dataset_path = Path(args.dataset)
    if not dataset_path.exists():
        print(f"\n[onboard] Dataset not found: {dataset_path}\n")
        sys.exit(1)

    print(f"\n[onboard] Loading dataset:  {dataset_path}")
    try:
        df = pd.read_csv(dataset_path, parse_dates=["Date"])
    except Exception as exc:
        print(f"[onboard] Failed to load dataset: {exc}\n")
        sys.exit(1)

    print(f"[onboard] Rows: {len(df)}  |  Parameter: {args.parameter}")

    sensors_config = load_sensor_config(args.sensors_config)
    models_store   = Path(args.models_store) / args.parameter.lower()

    result = onboard_new_parameter(
        config            = sensors_config,
        df                = df,
        parameter_name    = args.parameter,
        models_store_path = models_store,
    )

    # ── Interactive variant + rank selection ───────────────────────────────
    print("\n" + "═" * 62)
    print("  HUMAN REVIEW REQUIRED")
    print("═" * 62)

    if result.log_evaluated:
        print(f"  Two variants evaluated (signal CV={result.cv_signal:.1f}% > 60%):")
        print(f"    raw : rank-1 val RMSE = {result.report_raw.best.val_rmse:.4f}")
        print(f"    log : rank-1 val RMSE = {result.report_log.best.val_rmse:.4f}  "
              f"(back-transformed)")
        print(f"  Recommended: {result.recommended.upper()}")
        print()
        variant_input = (
            input(f"  Choose variant [raw / log]  (default: {result.recommended}): ")
            .strip().lower() or result.recommended
        )
        if variant_input not in ("raw", "log"):
            print(f"  Unknown variant '{variant_input}'. Aborting.")
            sys.exit(1)
    else:
        variant_input = "raw"
        print(f"  Only RAW variant evaluated (CV={result.cv_signal:.1f}% ≤ 60%).")

    chosen_report = result.report_raw if variant_input == "raw" else result.report_log
    n_results     = len(chosen_report.results)
    print(f"\n  Report has {n_results} ranked model(s). Enter the rank to freeze "
          f"(1 = best val RMSE).")
    try:
        rank_input = int(input(f"  Chosen rank [1–{n_results}]: ").strip())
    except ValueError:
        print("  Invalid rank. Aborting.")
        sys.exit(1)

    # ── Rebuild X_all / y_all for the chosen variant ───────────────────────
    sensor_entry = next(
        s for s in sensors_config["sensors"]
        if s["parameter_name"] == args.parameter
    )
    df_clean, frequency = _prepare_data(sensors_config, df.copy(), sensor_entry)

    if variant_input == "log":
        col    = sensor_entry["column_name"]
        col_lg = col + "_log"
        df_log = df_clean.copy()
        df_log[col_lg] = np.log1p(df_log[col])
        sensor_log = {**sensor_entry,
                      "column_name": col_lg, "parameter_name": col_lg}
        X_tr, y_tr, X_v, y_v, *_ = _build_and_split(df_log, sensor_log, frequency)
    else:
        X_tr, y_tr, X_v, y_v, *_ = _build_and_split(df_clean, sensor_entry, frequency)

    X_all = pd.concat([X_tr, X_v]).reset_index(drop=True)
    y_all = pd.concat([y_tr, y_v]).reset_index(drop=True)

    models_store.mkdir(parents=True, exist_ok=True)
    out = submit_benchmark_choice(
        report            = chosen_report,
        chosen_rank       = rank_input,
        models_store_path = models_store,
        X_all             = X_all,
        y_all             = y_all,
    )

    print(f"\n[onboard] Model frozen.")
    print(f"  Algorithm  : {out['algorithm']}")
    print(f"  Val RMSE   : {out['val_rmse']:.4f}")
    print(f"  Saved to   : {out['saved_path']}")
    print(f"  Pointer    : {out['pointer_path']}\n")


def _cmd_monitor(args: argparse.Namespace) -> None:
    """
    monitor: run one new measurement through the production model.

    new-row format
    --------------
    CSV (single row) or JSON with pre-engineered feature columns — the same
    columns that were used to train the production model.
    Use data/processed/<param>_X_test.csv as a reference for column names.
    Example: data/processed/ec_X_test.csv  (last row = most recent test measurement)

    For context-aware feature engineering (lag/rolling from raw sensor data),
    pass --dataset with the full historical CSV.  The CLI will append the
    new raw row, rebuild features, and use the last feature row.
    """
    import pickle
    import pandas as pd
    from src.retraining.model_versioning import load_current_model, read_current_model_pointer
    from src.monitor import ParameterMonitor, get_system_status
    from src.config import get_config

    param       = args.parameter
    store_path  = Path(args.models_store) / param.lower()
    pointer     = read_current_model_pointer(store_path)

    if pointer is None:
        print(f"\n[monitor] No production model found for '{param}' in {store_path}")
        print(f"  Run 'python run.py onboard --parameter {param}' first.\n")
        sys.exit(1)

    print(f"\n[monitor] Parameter     : {param}")
    print(f"[monitor] Model version : {pointer.get('model_version', '?')}")
    print(f"[monitor] Model path    : {pointer.get('model_path', '?')}")

    model = load_current_model(store_path)
    if model is None:
        print(f"\n[monitor] Could not load model from {store_path}\n")
        sys.exit(1)

    # ── Load the new row ───────────────────────────────────────────────────
    row_path = Path(args.new_row)
    if not row_path.exists():
        print(f"\n[monitor] --new-row file not found: {row_path}\n")
        sys.exit(1)

    suffix = row_path.suffix.lower()
    if suffix == ".json":
        new_row = pd.read_json(row_path, lines=False)
        if isinstance(new_row, pd.Series):
            new_row = new_row.to_frame().T
    else:
        new_row = pd.read_csv(row_path)

    # Use only the last row if the file contains more than one
    if len(new_row) > 1:
        print(f"[monitor] --new-row has {len(new_row)} rows; using the last row.")
        new_row = new_row.tail(1).reset_index(drop=True)

    print(f"[monitor] Feature columns: {list(new_row.columns)}")

    # ── Build a minimal ParameterMonitor ──────────────────────────────────
    cfg = get_config()

    monitor = ParameterMonitor(
        parameter_name    = param,
        prediction_model  = model,
        feature_fn        = lambda df: (None, None),  # not invoked without retrain_manager
        retrain_manager   = None,
        anomaly_detector  = None,
        forecaster        = None,
        models_store_path = store_path,
        config            = cfg,
    )

    actual = float(args.actual_value) if args.actual_value is not None else None

    result = monitor.process_new_measurement(new_row, actual_value=actual)

    # ── Display result ─────────────────────────────────────────────────────
    SEP = "─" * 58
    print(f"\n{SEP}")
    print(f"  MONITOR RESULT — {param}")
    print(SEP)
    print(f"  Timestamp       : {result.timestamp}")
    print(f"  Prediction      : {result.prediction:.4f}"
          if result.prediction is not None else "  Prediction      : —")
    if result.residual is not None:
        print(f"  Actual value    : {actual:.4f}")
        print(f"  Residual        : {result.residual:+.4f}")
    if result.prediction_shap:
        print(f"  Top SHAP feature: {result.prediction_shap[0]}")
    if result.anomaly_detected is not None:
        flag = "⚠ ANOMALY" if result.anomaly_detected else "OK"
        print(f"  Anomaly         : {flag}  (score={result.anomaly_score:.3f})")
    if result.retrain_alert:
        print(f"  Retrain alert   : {result.retrain_alert}")
    print(SEP)
    exports_dir = Path(cfg.exports.exports_dir)
    print(f"  Export appended : {exports_dir / (param + '.jsonl')}")
    print()


def _cmd_status(args: argparse.Namespace) -> None:
    """
    status: print current operational state for one or all parameters.

    Without --parameter: scans models_store/ for every sub-directory that
    contains a current_model.json and prints status for each.
    """
    from src.monitor import get_system_status

    store_root = Path(args.models_store)
    SEP  = "─" * 58
    SEP2 = "═" * 58

    if args.parameter:
        params = [args.parameter]
        store_dirs = [store_root / args.parameter.lower()]
    else:
        # Discover all parameter stores
        if not store_root.exists():
            print(f"\n[status] models_store not found at: {store_root}\n")
            sys.exit(1)
        store_dirs = sorted(
            d for d in store_root.iterdir()
            if d.is_dir() and (d / "current_model.json").exists()
        )
        params = [d.name for d in store_dirs]

    if not params:
        print(f"\n[status] No models found in {store_root}\n")
        print(f"  Run 'python run.py onboard --parameter <name>' to onboard a parameter.\n")
        return

    print(f"\n{SEP2}")
    print(f"  SYSTEM STATUS  ({len(params)} parameter(s))")
    print(SEP2)

    for param, store_dir in zip(params, store_dirs):
        s = get_system_status(param.upper() if args.parameter else param, store_dir)
        print(f"\n  Parameter             : {s.parameter_name}")
        print(f"  Model version         : {s.model_version or '— not set'}")
        print(f"  Last promoted         : {s.last_promoted_at or '— never'}")
        print(f"  Consecutive rejections: {s.consecutive_rejections}")
        print(f"  Pending approvals     : {s.pending_approvals}")
        print(f"  Last prediction       : "
              f"{s.last_prediction:.4f}" if s.last_prediction is not None
              else "  Last prediction       : — (no measurement processed yet)")
        print(f"  Queried at            : {s.queried_at}")
        print(SEP)


def _cmd_approve(args: argparse.Namespace) -> None:
    """
    approve: delegate entirely to cli_approve.main().

    Forwards all unknown arguments verbatim so every cli_approve option
    (--reject-all-stale, --stale-days, --models-store, approval_id) works
    exactly as documented in src/retraining/cli_approve.py.
    """
    from src.retraining.cli_approve import main as _approve_main

    _approve_main(
        argv         = args.approve_args,
        models_store = Path(args.models_store),
    )


# ══════════════════════════════════════════════════════════════════════════════
# Argument parser
# ══════════════════════════════════════════════════════════════════════════════

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog        = "python run.py",
        description = "Water-quality monitoring pipeline — unified entry point.",
        formatter_class = argparse.RawDescriptionHelpFormatter,
    )

    # Global overrides (accepted by all sub-commands)
    parser.add_argument(
        "--system-config",
        default = str(_DEFAULT_SYSTEM_CONFIG),
        metavar = "PATH",
        help    = f"Path to system_config.json (default: {_DEFAULT_SYSTEM_CONFIG})",
    )
    parser.add_argument(
        "--sensors-config",
        default = str(_DEFAULT_SENSORS_CONFIG),
        metavar = "PATH",
        help    = f"Path to sensors_config.json (default: {_DEFAULT_SENSORS_CONFIG})",
    )
    parser.add_argument(
        "--models-store",
        default = str(_DEFAULT_MODELS_STORE),
        metavar = "PATH",
        help    = f"Root of models_store/ directory (default: {_DEFAULT_MODELS_STORE})",
    )

    subs = parser.add_subparsers(dest="command", metavar="<command>")
    subs.required = True

    # ── onboard ───────────────────────────────────────────────────────────
    p_onboard = subs.add_parser(
        "onboard",
        help        = "Benchmark and freeze a model for a new sensor parameter.",
        description = (
            "Runs the full benchmark pipeline (RF / XGBoost / SVR), prints the\n"
            "report, asks you to choose a variant and rank, then freezes the model."
        ),
    )
    p_onboard.add_argument(
        "--dataset", required=True, metavar="PATH",
        help="CSV dataset with Date and sensor columns (e.g. data/processed/c1_with_wqi.csv).",
    )
    p_onboard.add_argument(
        "--parameter", required=True, metavar="NAME",
        help="Parameter to onboard — must match a 'parameter_name' in sensors_config.json.",
    )

    # ── monitor ───────────────────────────────────────────────────────────
    p_monitor = subs.add_parser(
        "monitor",
        help        = "Process one new sensor measurement through the production model.",
        description = (
            "Loads the frozen production model for --parameter, runs prediction\n"
            "and SHAP explanation on --new-row, and appends the result to the\n"
            "rolling JSONL export (exports/<parameter>.jsonl).\n\n"
            "new-row format: CSV or JSON with pre-engineered feature columns\n"
            "(same columns used during training).  If the file has multiple rows,\n"
            "only the last row is used.  See data/processed/<param>_X_test.csv\n"
            "for the expected column format."
        ),
    )
    p_monitor.add_argument(
        "--parameter", required=True, metavar="NAME",
        help="Parameter name (e.g. EC, pH, Turbidity).",
    )
    p_monitor.add_argument(
        "--new-row", required=True, metavar="PATH",
        help="Path to a CSV or JSON file containing the new feature row.",
    )
    p_monitor.add_argument(
        "--actual-value", default=None, type=float, metavar="FLOAT",
        help="Actual measured value (optional). Enables residual and anomaly scoring.",
    )

    # ── status ────────────────────────────────────────────────────────────
    p_status = subs.add_parser(
        "status",
        help        = "Show current operational status for one or all parameters.",
        description = (
            "Without --parameter: scans models_store/ and shows status for every\n"
            "parameter that has a current_model.json."
        ),
    )
    p_status.add_argument(
        "--parameter", default=None, metavar="NAME",
        help="If given, show status for this parameter only.",
    )

    # ── approve ───────────────────────────────────────────────────────────
    p_approve = subs.add_parser(
        "approve",
        help        = "Review / approve / reject pending model candidates.",
        description = (
            "Delegates to src/retraining/cli_approve.py.\n"
            "Without arguments: lists all pending approvals.\n"
            "With an ID:        interactive y/n decision for that approval.\n"
            "--reject-all-stale [--stale-days N]: list approvals older than N days."
        ),
    )
    p_approve.add_argument(
        "approve_args",
        nargs   = argparse.REMAINDER,
        help    = "Arguments forwarded verbatim to cli_approve (approval_id, --reject-all-stale, …).",
    )

    return parser


# ══════════════════════════════════════════════════════════════════════════════
# Entry point
# ══════════════════════════════════════════════════════════════════════════════

def main(argv: list[str] | None = None) -> None:
    # ── Bootstrap: ensure project root is on sys.path ─────────────────────
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))

    parser = _build_parser()
    args   = parser.parse_args(argv)

    # ── Config validation (before any src import) ─────────────────────────
    _validate_configs(
        system_config_path  = Path(args.system_config),
        sensors_config_path = Path(args.sensors_config),
    )

    # ── Logging setup ─────────────────────────────────────────────────────
    from src._logging import setup_logging_from_config
    setup_logging_from_config(config_path=Path(args.system_config))

    # ── Dispatch ──────────────────────────────────────────────────────────
    dispatch = {
        "onboard": _cmd_onboard,
        "monitor": _cmd_monitor,
        "status":  _cmd_status,
        "approve": _cmd_approve,
    }
    dispatch[args.command](args)


if __name__ == "__main__":
    main()
